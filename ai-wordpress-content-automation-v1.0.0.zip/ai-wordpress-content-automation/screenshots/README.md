# Workflow Screenshots & Visual Documentation

This directory contains visual assets and diagrams documenting the **AI-Powered WordPress Content Automation** n8n workflow.

## Overview Diagram

```
+---------------------------------------------------------------------------------------------------+
|                            AI-POWERED WORDPRESS CONTENT AUTOMATION                                |
+---------------------------------------------------------------------------------------------------+
  [Webhook Trigger] ----+
                        |--> [Settings & Normalizer] --> [AI Article Structure] --> [Research Stage]
  [Manual Trigger]  ----+                                                                   |
                                                                                            v
  [Validation Error] <-- (Invalid) <-- [Data Validation Gate] <-----------------------------+
                                              | (Valid)
                                              v
                                       [Chapter Split]
                                              |
                        +-------------------->|
                        |                     v
                        |           [Loop Over Chapters]
                        |                     |
                        |                     v
                        |          [AI Chapter Generation]
                        |                     |
                        +--- [Append Item] <--+
                                              | (Done)
                                              v
                                    [Content Assembler]
                                              |
                                              v
                                   [WordPress Draft Create]
                                              |
                                              v
                                    [AI Featured Image]
                                              |
                                              v
                                   [WordPress Media Upload]
                                              |
                                              v
                                    [Set Featured Media]
                                              |
                                              v
                                    [Final Status Response]
```

## Recommended Screenshot Assets

When deploying this repository or customizing for your team, save exported high-resolution screenshots here:

1. `01-n8n-canvas-overview.png`: Full workflow canvas visual showing all node groupings and active connections.
2. `02-ai-structure-node.png`: Node configuration inspector for the AI Article Structure generator.
3. `03-chapter-loop.png`: Inspector view showing the Chapter Split and Loop Over Chapters iteration nodes.
4. `04-wordpress-draft-output.png`: Sample WordPress Gutenberg editor view showing the auto-generated draft post, structured headings, and attached featured image.
5. `05-webhook-execution-history.png`: n8n Execution History panel showing a 100% green execution run with execution timing.
