# AI-Powered WordPress Content Automation

> **Engineered by SHADHIN AI**  
> *AI Automation • n8n • WordPress • AI Agents • API Integration*

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![n8n Workflow](https://img.shields.io/badge/n8n-Workflow%20v1.0.0-EA4B71.svg)](https://n8n.io)
[![WordPress REST API](https://img.shields.io/badge/WordPress-REST%20API%20v2-21759B.svg)](https://developer.wordpress.org/rest-api/)

**AI-Powered WordPress Content Automation** is an enterprise-grade, modular n8n workflow engineered to transform high-level content prompts into richly formatted, research-grounded, SEO-optimized WordPress draft articles complete with AI-generated featured images and automated media library management.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Key Features](#key-features)
- [Workflow Architecture](#workflow-architecture)
- [Mermaid Workflow Diagram](#mermaid-workflow-diagram)
- [Tech Stack](#tech-stack)
- [System Requirements](#system-requirements)
- [Installation & Setup](#installation--setup)
- [n8n Import Instructions](#n8n-import-instructions)
- [AI Model Configuration](#ai-model-configuration)
- [WordPress Configuration & Application Passwords](#wordpress-configuration--application-passwords)
- [Usage Examples](#usage-examples)
- [Error Handling & Resilience](#error-handling--resilience)
- [Security & Public Release Best Practices](#security--public-release-best-practices)
- [Limitations](#limitations)
- [Future Roadmap](#future-roadmap)
- [Screenshots](#screenshots)
- [License](#license)
- [Author & Brand](#author--brand)

---

## Project Overview

Traditional AI content generation pipelines often produce shallow, generic blog posts by attempting to generate an entire 2,000+ word article in a single prompt. This approach leads to:
- Context loss and repetitive phrasing.
- Inability to cover nuanced subtopics deeply.
- Keyword stuffing or fabricated citations and statistics.
- Clunky manual formatting and tedious copying into CMS editors.

**AI-Powered WordPress Content Automation** solves these challenges through a **two-phase generative workflow**:
1. **Strategic Structural Modeling:** An AI editorial strategist designs a high-intent article blueprint (outline, search intent, target keywords, ordered chapters, and FAQ opportunities) validated before execution.
2. **Sequential Chapter Generation:** Each chapter is crafted dynamically within an isolated loop, allowing the model to focus deeply on individual subtopics while adhering to strict natural language and SEO constraints.
3. **Automated WordPress Publishing Pipeline:** The resulting chapters are assembled with clean Gutenberg-compatible HTML, created as a WordPress **draft** (preventing unintentional auto-publishing), paired with an AI-generated featured image, uploaded to the WordPress Media Library, and linked automatically.

---

## Key Features

- **Dual-Trigger Execution:** Trigger on-demand via the n8n UI canvas (Manual Trigger) or automate programmatically via HTTP REST Webhook.
- **Dynamic Parameter Normalization:** Supports custom `topic`, `target_audience`, `language`, `tone`, `content_type`, `target_keyword`, and `additional_instructions`.
- **Structured JSON Article Outlines:** Enforces structured editorial planning with JSON Schema response validation.
- **Configurable Research Stage:** Integrates external search APIs (Tavily, Perplexity, or custom search) to ground articles on real facts while preserving source titles and URLs.
- **Strict Anti-Hallucination Constraints:** Explicit prompt guardrails prevent synthetic citations, fake numbers, and invented studies.
- **Strict SEO Standards:** Natural keyword distribution without keyword stuffing.
- **Strict Draft Status Guarantee:** Posts are always saved as `draft`—never automatically published without human editorial review.
- **End-to-End Media Pipeline:** Generates tailored featured image prompts, invokes DALL-E 3, downloads the binary, uploads to the WordPress Media Library with proper MIME types, and binds the `featured_media` ID.
- **Comprehensive Failure Isolation:** Graceful fallbacks and detailed error reporting ensure that non-critical failures (such as media upload) do not corrupt the post draft.

---

## Workflow Architecture

The workflow follows a 13-stage sequential execution model:

```
User Input
    ↓
Settings / Configuration
    ↓
AI Article Structure
    ↓
Research
    ↓
Data Validation
    ↓
Chapter Split
    ↓
AI Chapter Content Generation
    ↓
Content Merge / Preparation
    ↓
WordPress Draft Creation
    ↓
AI Featured Image
    ↓
WordPress Media Upload
    ↓
Set Featured Image
    ↓
Final Response / Status
```

---

## Mermaid Workflow Diagram

```mermaid
flowchart TD
    A[User Input] --> B[Settings]
    B --> C[AI Article Structure]
    C --> D[Research]
    D --> E[Data Validation]
    E --> F[Chapter Split]
    F --> G[AI Chapter Generation]
    G --> H[Content Merge]
    H --> I[WordPress Draft]
    I --> J[AI Featured Image]
    J --> K[WordPress Media Upload]
    K --> L[Set Featured Image]
    L --> M[Final Response]
```

---

## Tech Stack

| Component | Technology | Role |
| :--- | :--- | :--- |
| **Orchestration** | [n8n](https://n8n.io) (v1.x+) | Workflow automation engine, looping, and data transformation |
| **Language Models** | OpenAI GPT-4o / GPT-4o-mini | Strategic outline generation and chapter-by-chapter drafting |
| **Image Generation** | OpenAI DALL-E 3 | Contextual editorial featured image generation |
| **CMS Platform** | WordPress (v5.6+) | Content management system via native REST API v2 |
| **Authentication** | WordPress Application Passwords | Secure, revocable API access without exposing main user passwords |
| **Research (Optional)** | Tavily / Perplexity API | Real-time web retrieval for grounding and source verification |

---

## System Requirements

- **n8n Instance:** Self-hosted (Docker / npm) or n8n Cloud (v1.20.0 or later recommended).
- **WordPress Site:** Self-hosted WordPress 5.6+ with:
  - Pretty permalinks enabled (`Settings > Permalinks` set to Post name).
  - HTTPS / SSL active (WordPress Application Passwords require HTTPS in production).
  - User account with `Editor` or `Administrator` privileges.
- **API Keys:**
  - OpenAI API Key (or OpenAI-compatible endpoint).
  - (Optional) Tavily or Perplexity API key for web research.

---

## Installation & Setup

1. **Clone the Repository:**
   ```bash
   git clone https://github.com/your-username/ai-wordpress-content-automation.git
   cd ai-wordpress-content-automation
   ```

2. **Configure Environment Variables:**
   Copy the example environment file:
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your preferred editor and provide your endpoints and keys.

3. **Deploy or Run n8n:**
   If running n8n via Docker:
   ```bash
   docker run -it --rm --name n8n -p 5678:5678 -v ~/.n8n:/home/node/.n8n n8nio/n8n
   ```

---

## n8n Import Instructions

1. Open your n8n web dashboard (`http://localhost:5678` or your hosted URL).
2. In the left navigation bar, select **Workflows**.
3. In the top-right corner, click **Add Workflow** (or **+**).
4. Click the three dots menu (**...**) in the upper right corner of the canvas and choose **Import from File**.
5. Select `workflow/wordpress-ai-content-automation.json` from this repository.
6. The full workflow canvas will render automatically with all nodes, connections, and layout coordinates.
7. Open the **Settings** node to verify or configure your variables, or configure environment variables in your n8n host environment.
8. Click **Save** and toggle the workflow **Active** if you wish to listen for Webhook calls.

---

## AI Model Configuration

In the **Settings** node (or via `.env`), you can specify:
- `AI_BASE_URL`: Defaults to `https://api.openai.com/v1`. Compatible with local LLMs (Ollama, vLLM) or alternative providers (Azure OpenAI, OpenRouter).
- `AI_MODEL_STRUCTURE`: Recommended `gpt-4o` for high-reasoning outline planning.
- `AI_MODEL_CHAPTER`: `gpt-4o` or `gpt-4o-mini` for high-throughput, coherent chapter generation.
- `AI_IMAGE_MODEL`: `dall-e-3` for rich, crisp featured header images.

---

## WordPress Configuration & Application Passwords

To enable secure REST API publishing:
1. Log in to your WordPress Admin dashboard (`/wp-admin`).
2. Navigate to **Users > Profile** (or **Users > All Users** and edit your automation user).
3. Scroll down to the **Application Passwords** section.
4. Enter a descriptive Application Name (e.g. `n8n-content-automation`) and click **Add New Application Password**.
5. Copy the generated 24-character password (e.g., `xxxx xxxx xxxx xxxx xxxx xxxx`).
6. Set your credentials in n8n or `.env`:
   - `WORDPRESS_URL`: `https://example.com` (no trailing slash)
   - `WORDPRESS_USERNAME`: `automation_user`
   - `WORDPRESS_APPLICATION_PASSWORD`: `xxxx xxxx xxxx xxxx xxxx xxxx`

*Note: For detailed security settings and Apache/Nginx authentication header fixes, refer to [`docs/wordpress-setup.md`](docs/wordpress-setup.md).*

---

## Usage Examples

### 1. Manual Canvas Execution
Open the workflow in n8n, click the **Manual Trigger** node, click **Test step**, and click **Execute Workflow**. The workflow will execute using the built-in sample payload.

### 2. HTTP Webhook Request
Send a `POST` request to your n8n production webhook URL:

```bash
curl -X POST "https://your-n8n-instance.com/webhook/wp-content-automation" \
     -H "Content-Type: application/json" \
     -d '{
       "topic": "How AI automation helps small businesses",
       "target_audience": "Small business owners",
       "language": "English",
       "tone": "Professional",
       "content_type": "Blog Article",
       "target_keyword": "AI automation for small business",
       "additional_instructions": "Include practical operational examples in inventory and customer service."
     }'
```

### Expected Response Payload
```json
{
  "workflow_status": "success",
  "execution_id": "exec-1728250000000-a1b2c3",
  "wordpress": {
    "post_id": 1420,
    "post_url": "https://your-wordpress-site.com/?p=1420",
    "post_status": "draft",
    "featured_media_id": 1421,
    "featured_image_status": "attached"
  },
  "article_summary": {
    "title": "Unlocking Efficiency: How AI Automation Empowers Small Businesses",
    "target_keyword": "AI automation for small business",
    "language": "English",
    "tone": "Professional"
  },
  "errors": [],
  "completed_at": "2026-10-06T10:15:30.000Z"
}
```

---

## Error Handling & Resilience

The workflow employs an isolated failure handling pattern:
- **Validation Barrier:** If incoming user parameters are incomplete or the AI structure returns invalid JSON, execution halts immediately and returns an informative HTTP 400 response.
- **Non-Fatal Image Degradation:** The DALL-E 3 image generation and media upload stages use `continueOnFail: true`. If image generation quota is exceeded or an upload times out, the WordPress draft remains intact, and the final response reports `"partial_success"` with diagnostic logs.
- **Safe State Isolation:** The loop accumulator isolates chapter states, ensuring that network hiccups during chapter generation do not corrupt earlier chapters.

---

## Security & Public Release Best Practices

- **Zero Hardcoded Secrets:** No API keys, passwords, or personal tokens are embedded in the workflow JSON.
- **Dedicated Service User:** Never use your WordPress master administrator credentials. Create a dedicated editor account for automation.
- **Scoped Application Passwords:** WordPress Application Passwords can be revoked with a single click in `/wp-admin` without changing user passwords.
- **Public GitHub Hygiene:** Review [`docs/security.md`](docs/security.md) for full pre-commit security checklists.

---

## Limitations

- **Draft Publishing Only:** By design, the workflow creates drafts. Publishing requires human review or explicit downstream publishing workflows.
- **WordPress Permalinks:** Requires plain permalinks to be disabled in WordPress (`/index.php?p=123` can break some REST endpoints).
- **Execution Timeout:** Long articles (8+ chapters) may exceed standard HTTP proxy timeouts (e.g. Cloudflare 100s). For large multi-chapter articles, run n8n with background queue mode or increase gateway timeouts.

---

## Future Roadmap

- [ ] Multi-image chapter insertion (inline infographics).
- [ ] Direct Yoast / RankMath SEO meta field injection via custom REST meta fields.
- [ ] Automated internal linking via WordPress site search endpoint.
- [ ] Slack / Discord notification webhook upon draft readiness.

---

## Screenshots

Refer to [`screenshots/README.md`](screenshots/README.md) for canvas layout details and visual references.

---

## License

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

---

## Author & Brand

**SHADHIN AI**  
*AI Automation • n8n • WordPress • AI Agents • API Integration*  
Providing modern, open-source automation blueprints for digital creators and enterprises.
