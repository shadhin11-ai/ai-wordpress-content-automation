# Enterprise Security & Credential Hygiene

Because this repository and its workflows are intended for public distribution and enterprise automation, adhering to strict security practices is vital.

---

## 1. Zero Credential Leakage Architecture

- **No Hardcoded Secrets:** The exported `workflow/wordpress-ai-content-automation.json` file contains **zero hardcoded passwords, tokens, or live URLs**.
- **Dynamic Expression Injection:** Values are retrieved at runtime from `$env` or dynamic expression bindings.
- **Git Hygiene:** The included `.gitignore` rigorously excludes `.env`, `.env.*`, `credentials.json`, `*.pem`, `*.key`, and backup files.

---

## 2. Principle of Least Privilege for WordPress

1. **Never Use Main Administrator Credentials:**
   Automated integrations should never run as User ID 1 or the primary site owner.
2. **Assign the Editor Role:**
   The `Editor` role grants sufficient capabilities to create drafts, edit posts, and upload media attachments, but prevents plugin installation, theme modification, or user management.
3. **Use Revocable Application Passwords:**
   If an automation credential is ever suspected of compromise, revoke it instantly in **WP Admin > Users > Profile > Application Passwords** without affecting user passwords or requiring site-wide password resets.

---

## 3. Webhook Security & Ingestion Hardening

When exposing n8n Webhook nodes to the public internet:
1. **Header Secret Verification:** Configure a secret header (e.g. `X-Webhook-Secret: your-secret-token`) and validate it in the `Settings & Input Normalizer` node before execution.
2. **Reverse Proxy Rate Limiting:** Place n8n behind Cloudflare, Nginx, or an API Gateway with rate limits (e.g., maximum 10 requests per minute) to protect against DoS attacks or unauthorized LLM quota consumption.
3. **Payload Sanitization:** The workflow strips script tags and normalizes inputs to guard against prompt injection and cross-site scripting (XSS) within WordPress post HTML.

---

## 4. Pre-Commit Checklist for Public GitHub Deployment

Before pushing to a public repository:
- [x] Run `git status` and verify that `.env` is untracked and ignored.
- [x] Run `grep -ri "sk-" .` to ensure no live OpenAI API keys exist in workflow files.
- [x] Run `grep -ri "Basic " workflow/` to ensure no live Base64 authorization headers are hardcoded.
- [x] Verify that `.env.example` contains only generic placeholder values.
