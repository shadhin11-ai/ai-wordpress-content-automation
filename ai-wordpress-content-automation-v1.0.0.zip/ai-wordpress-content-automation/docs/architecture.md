# Architecture & Technical Design

This document details the system architecture, state transitions, data contracts, and fault-tolerance mechanisms of the **AI-Powered WordPress Content Automation** workflow.

---

## High-Level Topology

```
+-----------------------------------------------------------------------------+
|                               Input Layer                                   |
|   [Webhook Trigger] (POST JSON)  OR  [Manual Trigger] (Canvas Testing)       |
+-----------------------------------------------------------------------------+
                                       |
                                       v
+-----------------------------------------------------------------------------+
|                            Configuration Layer                              |
|   [Settings & Normalizer]: Sets defaults, normalizes params, builds auth    |
+-----------------------------------------------------------------------------+
                                       |
                                       v
+-----------------------------------------------------------------------------+
|                            Intelligence Layer                               |
|   1. [AI Article Structure]: LLM Strategic Outline (JSON Schema mode)       |
|   2. [Research Stage]: Configurable web source gathering & citation check   |
|   3. [Data Validation]: Schema, sections integrity, and credential gates   |
+-----------------------------------------------------------------------------+
                                       |
                                       v
+-----------------------------------------------------------------------------+
|                       Sequential Content Generator                          |
|   [Chapter Split] -> [Loop Over Chapters (Batch Size 1)]                    |
|          |                     |                                            |
|          |                     v                                            |
|          |            [AI Chapter Generation] (Strict HTML, No stuffing)    |
|          |                     |                                            |
|          +--- [Append Item] <--+                                            |
+-----------------------------------------------------------------------------+
                                       | (Loop Complete)
                                       v
+-----------------------------------------------------------------------------+
|                           Assembly & Formatting                             |
|   [Content Merge]: Lead paragraph, ordered chapters, FAQ block, conclusion  |
+-----------------------------------------------------------------------------+
                                       |
                                       v
+-----------------------------------------------------------------------------+
|                           WordPress Integration                             |
|   1. [WordPress Draft]: POST /wp-json/wp/v2/posts (status: draft)           |
|   2. [AI Featured Image]: POST /v1/images/generations (DALL-E 3)            |
|   3. [Binary Download]: GET image URL -> binary stream                      |
|   4. [WordPress Media]: POST /wp-json/wp/v2/media (multipart binary)        |
|   5. [Set Featured Media]: POST /wp-json/wp/v2/posts/{id} (link attachment)|
+-----------------------------------------------------------------------------+
                                       |
                                       v
+-----------------------------------------------------------------------------+
|                              Response Layer                                 |
|   [Final Response Formatter] -> [Respond to Webhook]                        |
+-----------------------------------------------------------------------------+
```

---

## Data Contracts & Node Specifications

### 1. Inbound Request Schema
```json
{
  "topic": "string (required)",
  "target_audience": "string (optional, defaults to general audience)",
  "language": "string (optional, defaults to English)",
  "tone": "string (optional, defaults to Professional)",
  "content_type": "string (optional, defaults to Blog Article)",
  "target_keyword": "string (required)",
  "additional_instructions": "string (optional)"
}
```

### 2. Strategic Outline Contract (Node: `AI Article Structure`)
The model is instructed with `response_format: { type: "json_object" }` to ensure deterministic parsing:
```json
{
  "title": "string",
  "search_intent": "string",
  "target_keyword": "string",
  "supporting_keywords": ["string"],
  "introduction": "string",
  "sections": [
    {
      "section_number": 1,
      "chapter_title": "string",
      "subsections": ["string"],
      "key_points": ["string"]
    }
  ],
  "faq_opportunities": [
    {
      "question": "string",
      "answer_outline": "string"
    }
  ],
  "conclusion": "string"
}
```

### 3. Chapter Iteration Contract (Node: `Loop Over Chapters`)
Chapters are processed sequentially (`batchSize: 1`). Each chapter receives:
- Article title and overall thesis statement.
- Current chapter index and total chapter count (e.g. `Chapter 2 of 5`).
- Precise subtopics and key points for the active chapter.
- Target keyword and strict instruction against keyword stuffing.
- Tone and language constraints.

### 4. Assembled WordPress Payload Contract (Node: `Content Merge`)
Produces Gutenberg-compliant markup blocks:
- Introduction wrapped in `<p class="article-lead">`.
- Chapter headings structured strictly as semantic `<h2>` and subsections as `<h3>`.
- FAQ section formatted as semantic HTML schema ready for Google Rich Snippets.
- Post status explicitly locked to `"draft"`.

---

## Fault Isolation Strategy

| Stage | Failure Scenario | System Behavior |
| :--- | :--- | :--- |
| **Validation Gate** | Missing keyword or malformed JSON outline | Workflow terminates at `Is Valid?` node; returns HTTP 400 with diagnostic errors. |
| **Chapter Generation** | Upstream LLM rate limit or temporary timeout | Node configured with retries; fallback content block inserted to prevent complete pipeline crash. |
| **WordPress Draft** | Invalid WP credentials or permalink error | Flags error in final response; halts image pipeline to prevent orphaned media uploads. |
| **Featured Image** | DALL-E quota limit or OpenAI service outage | Flagged as non-fatal; draft post remains saved; returns `"partial_success"` with post details. |
| **Media Upload** | WordPress upload directory permissions issue | Flagged as non-fatal; draft post remains saved without featured image. |
