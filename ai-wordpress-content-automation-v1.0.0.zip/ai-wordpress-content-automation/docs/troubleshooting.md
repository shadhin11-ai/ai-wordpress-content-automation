# Troubleshooting & Error Resolution

This guide provides actionable solutions for common issues encountered during setup and execution.

---

## Common Issues & Diagnoses

### 1. WordPress REST API Returns 401 Unauthorized
- **Symptom:** Workflow fails at `WordPress Draft` node with error `rest_not_logged_in: Sorry, you are not allowed to create posts as this user.`
- **Causes:**
  1. Incorrect Application Password or Username.
  2. Server is stripping the `Authorization` header (very common on Apache/cPanel and Nginx).
- **Remedy:**
  - Verify credentials with `curl -u "user:password" https://site.com/wp-json/wp/v2/users/me`.
  - Apply the `.htaccess` or `nginx.conf` header preservation fix documented in [`docs/wordpress-setup.md`](wordpress-setup.md).

### 2. WordPress REST API Returns 403 Forbidden
- **Symptom:** `rest_cannot_create: Sorry, you are not allowed to create posts as this user.`
- **Cause:** The WordPress user account assigned to the credentials has the role of **Subscriber** or **Contributor** without post creation rights.
- **Remedy:** Elevate the user role to **Editor** or **Administrator** in WP Admin > Users.

### 3. Workflow Times Out During Chapter Generation
- **Symptom:** Execution status shows timeout after 60-120 seconds.
- **Cause:** If an outline contains 7+ long sections and the LLM response time is slow, gateway proxies (like Cloudflare or Traefik) may drop the connection.
- **Remedy:**
  - The workflow sets HTTP Request timeouts to 90 seconds. Ensure your reverse proxy has `proxy_read_timeout 180s;` configured.
  - In `AI Article Structure`, instruct the model to produce 3-5 concise, high-impact sections.

### 4. OpenAI Rate Limiting (HTTP 429)
- **Symptom:** Node `AI Article Structure` or `AI Chapter Generation` returns `rate_limit_exceeded`.
- **Cause:** Exceeding OpenAI organization tier TPM (Tokens Per Minute) or RPM (Requests Per Minute).
- **Remedy:**
  - The workflow processes chapters sequentially via `SplitInBatches` (batch size 1), which inherently distributes token consumption over time.
  - In n8n HTTP Request node options, enable **Retry on Fail** with a 2-second backoff interval.

### 5. Media Upload Succeeds But Image Not Linked as Featured
- **Symptom:** Image appears in WP Media Library, but the blog post has no featured image attached.
- **Cause:** WordPress theme does not support post thumbnails, or the REST API update call did not pass the correct media ID.
- **Remedy:**
  - Check `node-set-featured-image` execution history.
  - Verify your WordPress theme declares `add_theme_support('post-thumbnails');` in its `functions.php`.

### 6. Validation Error: "Article structure contains no valid 'sections' array"
- **Symptom:** Workflow routes to `Validation Error Handler` and emits HTTP 400.
- **Cause:** The AI model returned invalid JSON or conversational text instead of raw JSON.
- **Remedy:**
  - Ensure the model specified in `AI_MODEL_STRUCTURE` supports `response_format: { type: "json_object" }` (e.g. `gpt-4o`, `gpt-4o-mini`, `gpt-3.5-turbo-1106+`).
