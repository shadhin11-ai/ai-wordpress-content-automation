# End-to-End Setup Guide

This guide walks you through deploying and configuring the **AI-Powered WordPress Content Automation** workflow from scratch.

---

## Prerequisites

1. **n8n Automation Engine:**
   - Either self-hosted via Docker or npm, or an n8n Cloud account.
   - Recommended version: n8n v1.20+ (supporting modern HTTP Request node v4+ and SplitInBatches v3).
2. **WordPress Instance:**
   - Self-hosted WordPress site (v5.6 or higher) with HTTPS enabled.
   - Administrator or Editor user credentials.
3. **OpenAI API Key:**
   - An active OpenAI platform account with credits enabled for `gpt-4o` and `dall-e-3`.
4. **(Optional) Research API Key:**
   - Tavily (`tvly-...`) or Perplexity AI key for live web search grounding.

---

## Step 1: Clone Repository & Prepare Environment

```bash
git clone https://github.com/your-username/ai-wordpress-content-automation.git
cd ai-wordpress-content-automation
cp .env.example .env
```

Edit `.env` and fill in your details:
```env
WORDPRESS_URL=https://myblog.com
WORDPRESS_USERNAME=n8n_writer
WORDPRESS_APPLICATION_PASSWORD=abcd efgh ijkl mnop qrst uvwx
AI_API_KEY=sk-proj-yourOpenAiKeyHere
AI_MODEL_STRUCTURE=gpt-4o
AI_MODEL_CHAPTER=gpt-4o
AI_IMAGE_MODEL=dall-e-3
```

---

## Step 2: Configure WordPress Application Passwords

1. Open your WordPress Admin area: `https://your-site.com/wp-admin`.
2. Go to **Users > Profile** (or create a dedicated user under **Users > Add New** with the **Editor** role).
3. Scroll down to **Application Passwords**.
4. In the "New Application Password Name" field, enter: `n8n Automation`.
5. Click **Add New Application Password**.
6. WordPress will display a 24-character password formatted with spaces (e.g. `xxxx xxxx xxxx xxxx xxxx xxxx`).
7. Copy this password immediately. Store it securely.

*Note: The spaces in the application password are for readability; basic authentication handles them with or without spaces.*

---

## Step 3: Import Workflow into n8n

1. Access your n8n interface.
2. Click **Workflows** in the sidebar.
3. Click the **+ Add Workflow** button.
4. Open the top right context menu (**...**) and select **Import from File**.
5. Browse to `workflow/wordpress-ai-content-automation.json` in your cloned repository.
6. The entire workflow canvas will be loaded immediately.

---

## Step 4: Configure Credentials in n8n

You have two convenient options for handling credentials:

### Option A: Environment Variables (Recommended for Production)
If your n8n instance runs in Docker, pass environment variables via `docker-compose.yml` or `-e` flags:
```yaml
environment:
  - WORDPRESS_URL=https://myblog.com
  - WORDPRESS_USERNAME=n8n_writer
  - WORDPRESS_APPLICATION_PASSWORD=abcd efgh ijkl mnop qrst uvwx
  - AI_API_KEY=sk-proj-xxxxxx
```
The workflow's **Settings** node will automatically read these values from `$env`.

### Option B: Node-Level Configuration (Quickest for Testing)
Double click the **Settings** node on the n8n canvas and edit the fallback values in the JavaScript code:
```javascript
const wordpressUrl = "https://myblog.com";
const wordpressUsername = "n8n_writer";
const wordpressAppPassword = "abcd efgh ijkl mnop qrst uvwx";
const aiApiKey = "sk-proj-xxxxxx";
```

---

## Step 5: Test Execution

1. In the n8n canvas, click on the **Manual Trigger** node.
2. Click **Test step** to load the sample pinData.
3. Click **Execute Workflow** at the bottom of the canvas.
4. Watch each node light up green in sequence:
   - Outline generation (~5-10s)
   - Chapter generation loop (~15-30s depending on chapter count)
   - WordPress draft post creation (~1-2s)
   - DALL-E 3 image generation & media upload (~15s)
   - Final status compilation
5. Check your WordPress Admin under **Posts > All Posts**. You will see your new draft post complete with title, formatted content, and featured image!
