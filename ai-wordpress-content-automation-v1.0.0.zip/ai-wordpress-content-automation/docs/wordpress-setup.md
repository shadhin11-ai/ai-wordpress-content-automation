# WordPress Configuration & Application Passwords Guide

This guide details configuring your WordPress installation to accept REST API write operations from the n8n automation pipeline.

---

## 1. WordPress REST API Requirements

The workflow communicates with WordPress via the official **WordPress REST API (v2)**:
- Posts Endpoint: `POST /wp-json/wp/v2/posts`
- Media Endpoint: `POST /wp-json/wp/v2/media`
- Single Post Update: `POST /wp-json/wp/v2/posts/{id}`

### Essential WordPress Settings:
1. **Permalinks (Mandatory):**
   - Navigate to **Settings > Permalinks** in your WP Admin.
   - Ensure permalinks are set to **Post name** (`/%postname%/`) or any setting other than "Plain".
   - *Reason:* Plain permalinks (`?p=123`) can disable REST API path routing on certain server environments.
2. **HTTPS / SSL:**
   - WordPress requires an active HTTPS connection to accept Application Passwords.
   - If running locally on `http://localhost`, you can enable local testing by adding this to `wp-config.php`:
     ```php
     define('WP_ENVIRONMENT_TYPE', 'local');
     ```

---

## 2. Setting Up an Automation User

We strongly advise creating a dedicated user account specifically for automated publishing:

1. In WP Admin, navigate to **Users > Add New**.
2. Username: `automation_bot` (or similar).
3. Email: `automation@yourdomain.com`.
4. Role: **Editor** (Editors have permission to create drafts, upload media, and manage categories, without having full site administrative rights).
5. Click **Add New User**.

---

## 3. Creating an Application Password

1. While logged in as the new user (or as Admin), go to **Users > Profile**.
2. Scroll to the **Application Passwords** section.
3. Enter a label: `n8n Automation Engine`.
4. Click **Add New Application Password**.
5. Copy the 24-character generated token.
6. In n8n, this password is used in combination with the username as an HTTP Basic Auth header:
   `Authorization: Basic base64(username:password)`

---

## 4. Web Server Authorization Header Configuration

Some web hosting providers (Apache, Nginx, or Cloudflare) strip the `Authorization` header by default, causing WordPress REST API to return `401 Unauthorized` (`rest_not_logged_in`).

### For Apache (.htaccess fix):
Add these lines near the top of your WordPress `.htaccess` file:
```apache
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteCond %{HTTP:Authorization} ^(.*)
RewriteRule ^(.*) - [E=HTTP_AUTHORIZATION:%1]
</IfModule>
```

### For Nginx (nginx.conf fix):
Inside your `server` block or `location /` block:
```nginx
fastcgi_pass_header Authorization;
fastcgi_param HTTP_AUTHORIZATION $http_authorization;
```

---

## 5. Testing WordPress REST API Authentication

You can verify your credentials before running the n8n workflow using `curl`:

```bash
curl -X GET "https://your-site.com/wp-json/wp/v2/users/me" \
     -u "automation_user:xxxx xxxx xxxx xxxx xxxx xxxx"
```

If successful, WordPress will return your user object with `200 OK`. If you receive `401` or `403`, verify that Application Passwords are enabled and that your server preserves the `Authorization` header.
