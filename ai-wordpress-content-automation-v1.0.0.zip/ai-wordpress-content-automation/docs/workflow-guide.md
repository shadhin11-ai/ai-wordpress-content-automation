# Workflow Operations & Node-by-Node Guide

This document provides a detailed technical breakdown of every node in the **AI-Powered WordPress Content Automation** workflow.

---

## Node Reference Table

| Node Name | Type | Purpose | Error Behavior |
| :--- | :--- | :--- | :--- |
| **Webhook Trigger** | `webhook` | Listens for incoming POST calls on `/webhook/wp-content-automation` | Returns error response if body malformed |
| **Manual Trigger** | `manualTrigger` | Enables ad-hoc canvas runs with test pinData | N/A |
| **Settings** | `code` | Normalizes incoming payload and injects system credentials/defaults | Halts if script fails |
| **AI Article Structure** | `httpRequest` | Calls OpenAI API to generate structured JSON outline | `continueOnFail: true` |
| **Research** | `code` | Executes search API or applies grounded research parameters | Passes data to validation |
| **Data Validation** | `code` | Enforces schema integrity, checks sections array, audits credentials | Emits `is_valid: true/false` |
| **Is Valid?** | `if` | Routes valid execution to chapter split; invalid to error handler | Dual branch routing |
| **Validation Error Handler** | `code` | Formats HTTP 400 error payload with diagnostics | Connects to error webhook |
| **Respond Validation Error**| `respondToWebhook` | Emits HTTP 400 to caller | Terminates flow |
| **Chapter Split** | `code` | Transforms sections array into individual chapter queue items | Passes items to loop |
| **Loop Over Chapters** | `splitInBatches` | Loops through chapters sequentially (`batchSize: 1`) | Manages loop state |
| **AI Chapter Generation** | `httpRequest` | Generates deep, natural SEO chapter content | `continueOnFail: true` |
| **Append Chapter Content** | `code` | Appends chapter HTML into static accumulator and loops back | Recycles to loop node |
| **Content Merge** | `code` | Assembles full article HTML, intro, callouts, FAQs, and conclusion | Passes combined payload |
| **WordPress Draft** | `httpRequest` | `POST /wp-json/wp/v2/posts` with `status: draft` | `continueOnFail: true` |
| **Post Created?** | `if` | Verifies WordPress returned a valid numeric post ID | Routes to Image or Final |
| **AI Featured Image** | `httpRequest` | Requests DALL-E 3 image generation | `continueOnFail: true` |
| **Download Image Binary** | `httpRequest` | Downloads generated image URL into binary buffer | `continueOnFail: true` |
| **WordPress Media Upload** | `httpRequest` | `POST /wp-json/wp/v2/media` multipart binary upload | `continueOnFail: true` |
| **Set Featured Image** | `httpRequest` | `POST /wp-json/wp/v2/posts/{id}` linking `featured_media` | `continueOnFail: true` |
| **Final Response** | `code` | Builds unified output status and diagnostics | Passes to webhook response |
| **Respond to Webhook** | `respondToWebhook` | Emits HTTP 200 with complete execution summary | Final step |

---

## Detailed Node Walkthrough

### 1. Settings & Input Normalizer (`node-settings-normalizer`)
- **Inputs:** Extracts fields from webhook body or test input.
- **Fallbacks:**
  - `topic` defaults to `"How AI automation helps small businesses"`.
  - `language` defaults to `"English"`.
  - `tone` defaults to `"Professional"`.
  - `target_keyword` defaults to `"AI automation"`.
- **Security:** Assembles the Base64 HTTP Basic Authentication header dynamically without logging plaintext passwords.

### 2. AI Article Structure (`node-ai-article-structure`)
- **Model:** Configured via `AI_MODEL_STRUCTURE` (e.g. `gpt-4o`).
- **Prompt Architecture:** Uses system instructions requiring strict JSON output conforming to the required schema: `title`, `search_intent`, `target_keyword`, `supporting_keywords`, `introduction`, `sections`, `faq_opportunities`, and `conclusion`.
- **Timeout:** 60 seconds.

### 3. Data Validation Stage (`node-data-validation`)
- Validates that `parsed_structure` exists and parsed without syntax errors.
- Confirms `title` is non-empty string.
- Confirms `sections` is an array containing at least one section with `chapter_title`.
- Verifies WordPress connectivity readiness.

### 4. Chapter Split & Loop (`node-chapter-split` & `node-loop-chapters`)
- Splits the outline's sections array into distinct n8n items.
- Sets batch size to `1` so each section is drafted independently.
- Avoids token exhaustion, context drift, and superficial chapter treatment.

### 5. AI Chapter Content Generation (`node-ai-chapter-generation`)
- **Content Philosophy:**
  - **Natural SEO:** Weaves the primary keyword naturally into headers and body text without density stuffing.
  - **Anti-Hallucination:** Strictly forbids making up benchmark numbers, fake customer quotes, or pseudo-scientific citations.
  - **Semantic HTML:** Emits native `<h2>`, `<h3>`, `<p>`, `<ul>`, `<blockquote>`, and `<strong>` tags, avoiding markdown wrappers.

### 6. Content Merge & Preparation (`node-content-merge`)
- Pulls accumulated chapter fragments from execution context.
- Sorts chapters by their original index (`1, 2, 3...`) to guarantee flawless ordering.
- Appends introduction lead paragraph, FAQ schema blocks, and concluding takeaway.
- Sets WordPress post status explicitly to `"draft"`.

### 7. WordPress Media Pipeline (`node-ai-featured-image` -> `node-wp-media-upload` -> `node-set-featured-image`)
- Crafts a bespoke DALL-E 3 image generation prompt matching the article's core theme.
- Retrieves the generated image URL as a raw binary buffer (`responseFormat: "file"`).
- Uploads binary directly to `/wp-json/wp/v2/media` with `Content-Disposition: attachment; filename="ai-featured-image.jpg"`.
- Updates the draft post by assigning the returned media ID to the `featured_media` property.
