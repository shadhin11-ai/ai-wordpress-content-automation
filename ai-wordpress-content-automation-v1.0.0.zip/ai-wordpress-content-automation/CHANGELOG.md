# Changelog

All notable changes to the **AI-Powered WordPress Content Automation** project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-10-06

### Added
- Complete production-ready n8n workflow export (`workflow/wordpress-ai-content-automation.json`).
- Dual-trigger architecture supporting both automated HTTP Webhooks and on-demand Manual Canvas execution.
- Input normalizer and centralized settings node supporting flexible parameters (`topic`, `target_audience`, `language`, `tone`, `content_type`, `target_keyword`, `additional_instructions`).
- Structured AI Article Outline Generator using JSON Schema / Object mode (producing title, search intent, target keywords, supporting keywords, introduction, ordered sections with sub-points, FAQ opportunities, and conclusion).
- Configurable Research Stage integrating search providers (Tavily/Perplexity/Serper) to ground content and preserve verified source titles and URLs.
- Comprehensive Data Validation & Sanitization node with explicit verification gates for schema compliance, non-empty sections, and research data integrity.
- Sequential Chapter Splitter and loop processor maintaining strict chronological chapter ordering and context preservation across iterations.
- Natural SEO Content Generation per section, eliminating keyword stuffing and preventing synthetic citations or hallucinated statistics.
- Post-processing content assembler combining introduction, chapters, SEO-friendly headings, callout blocks, FAQ section, and conclusion into clean WordPress-compatible HTML.
- Native WordPress REST API integration for automated draft creation (`/wp-json/wp/v2/posts`) with strict `draft` status enforcement.
- Modular AI Featured Image Generation pipeline powered by DALL-E 3 with contextual visual prompt synthesis.
- WordPress Media Library binary upload stage (`/wp-json/wp/v2/media`) extracting media attachment IDs.
- Automated featured media attachment linking to the newly created WordPress draft post.
- Unified status and execution reporter returning execution ID, WordPress post ID, post URL, draft confirmation, and detailed error logs if partial failures occur.
- Complete documentation suite:
  - System Architecture (`docs/architecture.md`)
  - End-to-End Setup Guide (`docs/setup-guide.md`)
  - Workflow Operations Manual (`docs/workflow-guide.md`)
  - WordPress REST API & Application Password Guide (`docs/wordpress-setup.md`)
  - Troubleshooting & Error Resolution (`docs/troubleshooting.md`)
  - Enterprise Security & Credential Hygiene (`docs/security.md`)
- Sample input payload specification (`examples/sample-input.json`).
- Screenshots guidance and architecture diagrams (`screenshots/README.md`).
